package com.example.chat_application

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class SupportC : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_support_c)
    }
}